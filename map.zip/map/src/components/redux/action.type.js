export const ActionType={
    FETCH_DATA_EXCEL:"FETCH_DATA_EXCEL"
}